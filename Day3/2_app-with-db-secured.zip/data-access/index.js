const monk = require('monk');
const db = monk('localhost/appdb');
const collection = db.get("usercollection");

// console.log(collection);

exports.getAllUsers = function () {
    return new Promise((resolve, reject) => {
        collection.find().then((data) => {
            resolve(data);
        }, (err) => {
            reject("Connection Error....");
        });
    });
};

exports.getUser = function (userid) {
    return new Promise((resolve, reject) => {
        collection.findOne({ _id: monk.id(userid) }).then((data) => {
            resolve(data);
        }, (err) => {
            reject("User not Found....");
        });
    });
};

exports.insertUser = function (user) {
    return new Promise((resolve, reject) => {
        collection.insert(user).then((data) => {
            resolve(data);
        }, (err) => {
            reject("Insert User Failed....");
        });
    });
};

exports.updateUser = function (userid, user) {
    return new Promise((resolve, reject) => {
        collection.findOneAndUpdate({ _id: monk.id(userid) }, {$set: user}).then((data) => {
            resolve(data);
        }, (err) => {
            reject("Update User Failed");
        });
    });
}

exports.deleteUser = function (userid) {
    return new Promise((resolve, reject) => {
        collection.findOneAndDelete({ _id: monk.id(userid) }).then(() => {
            resolve("User Deleted");
        }, (err) => {
            reject("Delete User Failed");
        });
    });
}