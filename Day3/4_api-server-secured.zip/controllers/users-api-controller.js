const da = require('../data-access');

exports.getUsers = function (req, res, next) {
    da.getAllUsers().then((result) => {
        res.json({ data: result, message: "Success, Getting Users" });
    }, (eMsg) => {
        res.json({ data: [], message: "Error, Getting Users" });
    });
};

exports.getUser = function (req, res, next) {
    da.getUser(req.params.id).then((result) => {
        res.json({ data: result, message: "Success, Getting User" });
    }, (eMsg) => {
        res.json({ data: null, message: eMsg });
    });
};

exports.postUser = function (req, res, next) { 

}

exports.putUser = function (req, res, next) { 

}

exports.deleteUser = function (req, res, next) { 

}