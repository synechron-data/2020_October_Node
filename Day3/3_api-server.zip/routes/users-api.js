var express = require('express');
var router = express.Router();
var cors = require('cors');

const users_api_ctrl = require('../controllers/users-api-controller');

// Enabling CORS
// router.use(function (req, res, next) {
//     // update * to match the domain you will make the request from
//     res.header("Access-Control-Allow-Origin", "*");
//     next();
// });

router.use(cors());

router.get('/', users_api_ctrl.getUsers);

module.exports = router;
