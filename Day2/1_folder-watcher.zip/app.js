// const chokidar = require('chokidar');
// // console.log(chokidar);

// const watcher = chokidar.watch('./my-folder');

// watcher.on('add', (path) => { console.log(`File, ${path}, has been created....`); });
// watcher.on('change', (path) => { console.log(`File, ${path}, has been modified....`); });
// watcher.on('unlink', (path) => { console.log(`File, ${path}, has been deleted....`); });

// console.log("Chokidar is watching.....");

// -------------------------------------------------

const _ = require('lodash');

var random = _.random(1, 20);
console.log(random);

var employees = [{ id: 1, name: "Manish" },
{ id: 2, name: "Abhijeet" },
{ id: 3, name: "Ram" },
{ id: 4, name: "Abhishek" },
{ id: 5, name: "Ramakant" }];

console.log(employees[employees.length - 1]);

console.log(_.last(employees));